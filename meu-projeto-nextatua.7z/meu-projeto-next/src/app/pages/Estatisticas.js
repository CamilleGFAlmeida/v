import { DataTable } from "primereact/datatable"
import { Column } from "primereact/column"
import { Button } from "primereact/button"
import Head from "next/head"
import {
  HomeIcon,
  BarChartIcon,
  SettingsIcon,
  UsersIcon,
  LogOutIcon,
  RefreshCwIcon,
} from "lucide-react" // Importando os ícones

const estatisticasData = [
  {
    diretoria: "Luiz",
    qtdDiretoria: 200,
    setor: "TI",
    qtdSetor: 200,
    desligadoChapa: "308920",
    desligadoNome: "João",
    bloqueadoChapa: "102030",
    bloqueadoNome: "Rafael",
    naoEncontradoChapa: "506070",
    naoEncontradoNome: "Lucas",
    descricao: "",
  },
  {
    diretoria: "Luiz",
    qtdDiretoria: 200,
    setor: "TI",
    qtdSetor: 200,
    desligadoChapa: "308920",
    desligadoNome: "João",
    bloqueadoChapa: "102030",
    bloqueadoNome: "Rafael",
    naoEncontradoChapa: "506070",
    naoEncontradoNome: "Lucas",
    descricao: "",
  },
]

const MenuItem = ({ label, icon: Icon, selected = false }) => {
  return (
    <div
      className={`p-2 rounded-md cursor-pointer flex items-center gap-2 ${
        selected
          ? "bg-blue-100 text-blue-600 font-semibold"
          : "text-gray-600 hover:bg-blue-100 hover:text-blue-600"
      }`}
    >
      <Icon size={20} />
      {label}
    </div>
  )
}

const Estatisticas = () => {
  return (
    <>
      <Head>
        <title>Estatísticas</title>
      </Head>

      <div className="flex min-h-screen">
        {/* Sidebar */}
        <aside className="w-60 bg-white shadow-md p-5 flex flex-col justify-between">
          <div>
            <div className="mb-8">
              <img src="/assets/logo-vw.png" alt="Logo" className="w-8 h-8" />{" "}
              {/* mx-auto - centralização */}
            </div>
            <nav className="space-y-4">
              <MenuItem label="Estatísticas" icon={BarChartIcon} selected />
              <MenuItem label="Estações" icon={HomeIcon} />
              <MenuItem label="Usuários" icon={UsersIcon} />
              <div className="mt-8 text-gray-700 text-sm font-semibold">
                Alertas
              </div>
              <MenuItem label="Usuários" icon={UsersIcon} />
              <MenuItem label="FIS" icon={SettingsIcon} />
              <div className="mt-8 text-gray-700 text-sm font-semibold">
                Alterações
              </div>
              <MenuItem label="Usuários" icon={UsersIcon} />
              <MenuItem label="Permissões" icon={RefreshCwIcon} />
            </nav>
          </div>
          <button className="font-semibold text-left text-sm text-gray-600 hover:text-blue-600 flex items-center gap-3 mt-6">
            <LogOutIcon size={20} />
            Sair
          </button>
        </aside>

        {/* Conteúdo */}
        <main className="flex-1 p-8 bg-gray-50">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-semibold text-gray-800">
              Estatísticas
            </h1>
            <Button
              icon="pi pi-download"
              className="p-button-outlined text-gray-600 hover:text-gray-800"
              label="Download"
            />
          </div>

          <div className="bg-white shadow rounded-xl p-5 mb-8">
            <DataTable
              value={estatisticasData}
              responsiveLayout="scroll"
              className="text-sm"
            >
              <Column header="Diretoria" field="diretoria" />
              <Column header="Qtd" field="qtdDiretoria" />
              <Column header="Setor" field="setor" />
              <Column header="Qtd" field="qtdSetor" />
              <Column header="Chapa" field="desligadoChapa" />
              <Column header="Nome" field="desligadoNome" />
              <Column header="Chapa" field="bloqueadoChapa" />
              <Column header="Nome" field="bloqueadoNome" />
              <Column header="Chapa" field="naoEncontradoChapa" />
              <Column header="Nome" field="naoEncontradoNome" />
              <Column header="Descrição" field="descricao" />
            </DataTable>
          </div>

          {/* Título Gráficos e Botões */}
          <div className="mb-8">
            <h1 className="text-2xl font-semibold text-gray-800">Gráficos</h1>
            <div className="flex gap-4 mb-6 mt-6">
              <Button
                label="Quantidade por Setor"
                icon="pi pi-download"
                className="bg-blue-500 text-white hover:bg-blue-600 rounded-full px-6 py-3"
                iconClass="mr-2"
              />
              <Button
                label="Quantidade por Diretoria"
                icon="pi pi-download"
                className="bg-blue-500 text-white hover:bg-blue-600 rounded-full px-6 py-3"
                iconClass="mr-2"
              />
            </div>
          </div>

          {/* Rodapé */}
          <footer className="text-xs text-gray-500 text-center mt-134">
            09-04-2025 | Responsible department for filing: B-QAM | CSD-Class:
            0.1 · Max. 02 years | Internal
          </footer>
        </main>
      </div>
    </>
  )
}

export default Estatisticas
