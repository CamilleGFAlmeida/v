import React, { useState } from "react"
import {
  HomeIcon,
  BarChartIcon,
  SettingsIcon,
  UsersIcon,
  LogOutIcon,
  RefreshCwIcon,
} from "lucide-react"
import { Dropdown } from "primereact/dropdown"
import { Button } from "primereact/button"
import { Chart } from "primereact/chart"
import { DataTable } from "primereact/datatable"
import { Column } from "primereact/column"
import { Link, useLocation } from "react-router-dom"

export default function Home() {
  const location = useLocation()

  const [selectedResponsavel, setSelectedResponsavel] = useState(null)
  const [selectedArea, setSelectedArea] = useState(null)
  const [selectedSetor, setSelectedSetor] = useState(null)

  const responsaveis = [{ label: "Responsável", value: null }]
  const areas = [{ label: "Área", value: null }]
  const setores = [{ label: "Setor", value: null }]

  const usuarios = [
    {
      User_ID: "444444",
      Nome: "Everton",
      Setor: "QA Processos",
      Area: "TI",
      Diretoria: "Tito Jorge",
      Descricao: "TI",
      Status: "Ativo",
      UltimoAcesso: "04/04/2025",
      MesesSemAcesso: 0,
    },
    {
      User_ID: "444445",
      Nome: "Maria",
      Setor: "QA Processos",
      Area: "TI",
      Diretoria: "Tito Jorge",
      Descricao: "TI",
      Status: "Bloqueado Temporário",
      UltimoAcesso: "03/03/2025",
      MesesSemAcesso: 1,
    },
    {
      User_ID: "444446",
      Nome: "João",
      Setor: "QA Processos",
      Area: "TI",
      Diretoria: "Tito Jorge",
      Descricao: "TI",
      Status: "Bloqueado Definitivo",
      UltimoAcesso: "02/02/2025",
      MesesSemAcesso: 2,
    },
  ]

  const chartData = {
    labels: ["TEC", "PROD", "RH", "QUA", "LOG", "MAN", "ENG", "ADM"],
    datasets: [
      {
        label: "Usuários",
        data: [200, 300, 250, 400, 500, 450, 600, 700],
        backgroundColor: "#3B82F6",
      },
    ],
  }

  const MenuItem = ({ icon: Icon, label, selected }) => (
    <div
      className={`p-2 rounded-md cursor-pointer flex items-center gap-2 ${
        selected
          ? "bg-blue-100 text-blue-600 font-semibold"
          : "text-gray-600 hover:bg-blue-100 hover:text-blue-600"
      }`}
    >
      <Icon size={20} />
      {label}
    </div>
  )

  const totalUsuarios = usuarios.length
  const usuariosAtivos = usuarios.filter(
    (user) => user.Status === "Ativo"
  ).length
  const bloqueadosTemporarios = usuarios.filter(
    (user) => user.Status === "Bloqueado Temporário"
  ).length
  const bloqueadosDefinitivos = usuarios.filter(
    (user) => user.Status === "Bloqueado Definitivo"
  ).length

  const StatCard = ({ title, value, color, icon }) => {
    return (
      <div className="bg-gradient-to-r from-white to-gray-50 border border-gray-200 p-4 rounded-xl shadow hover:shadow-md transition-shadow duration-300 flex items-center gap-4">
        <div className={`p-3 rounded-full bg-gray-100 ${color}`}>{icon}</div>
        <div>
          <h3 className="text-sm text-gray-600 font-medium">{title}</h3>
          <p className={`text-2xl font-bold ${color}`}>{value}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="w-60 bg-white shadow-md p-5 flex flex-col justify-between">
        <div>
          <div className="mb-8">
            <img src="/assets/logo-vw.png" alt="Logo" className="w-8 h-8" />
          </div>

          <nav className="flex flex-col gap-6">
            {/* Menu Principal */}
            <div className="flex flex-col gap-4">
              <Link to="/Estatisticas">
                <MenuItem
                  icon={BarChartIcon}
                  label="Estatísticas"
                  selected={location.pathname === "/Estatisticas"}
                />
              </Link>
              <Link to="/Estacoes">
                <MenuItem
                  icon={HomeIcon}
                  label="Estações"
                  selected={location.pathname === "/GerenciamentoEstacoes"}
                />
              </Link>
              <Link to="/GerenciamentoUsuarios">
                <MenuItem
                  icon={UsersIcon}
                  label="Usuários"
                  selected={location.pathname === "/GerenciamentoUsuarios"}
                />
              </Link>
            </div>

            {/* Alertas */}
            <div className="flex flex-col gap-4">
              <div className="mt-3 text-gray-700 text-sm font-semibold">
                Alertas
              </div>
              <Link to="/Alertas/Usuarios">
                <MenuItem
                  icon={UsersIcon}
                  label="Usuários"
                  selected={location.pathname === "/Alertas/Usuarios"}
                />
              </Link>
              <Link to="/Alertas/FIS">
                <MenuItem
                  icon={SettingsIcon}
                  label="FIS"
                  selected={location.pathname === "/Alertas/FIS"}
                />
              </Link>
            </div>

            {/* Alterações */}
            <div className="flex flex-col gap-4">
              <div className="mt-3 text-gray-700 text-sm font-semibold">
                Alterações
              </div>
              <Link to="/Alteracoes/Usuarios">
                <MenuItem
                  icon={UsersIcon}
                  label="Usuários"
                  selected={location.pathname === "/Alteracoes/Usuarios"}
                />
              </Link>
              <Link to="/Alteracoes/Permissoes">
                <MenuItem
                  icon={RefreshCwIcon}
                  label="Permissões"
                  selected={location.pathname === "/Alteracoes/Permissoes"}
                />
              </Link>
            </div>
          </nav>
        </div>

        {/* Botão Sair */}
        <button className="font-semibold text-left text-sm text-gray-600 hover:text-blue-600 flex items-center gap-3 mt-6">
          <LogOutIcon size={20} />
          Sair
        </button>
      </aside>

      {/* Conteúdo principal */}
      <main className="flex-1 p-6 bg-gray-50">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-xl font-bold text-gray-800">Início</h1>
          <Button
            label="Download"
            icon="pi pi-download"
            className="p-button-outlined text-gray-600 hover:text-gray-800"
          />
        </div>

        {/* Filtros */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <Dropdown
            value={selectedResponsavel}
            options={responsaveis}
            onChange={(e) => setSelectedResponsavel(e.value)}
            placeholder="Responsável"
            className="w-full p-3 border-gray-200 rounded-full shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <Dropdown
            value={selectedArea}
            options={areas}
            onChange={(e) => setSelectedArea(e.value)}
            placeholder="Área"
            className="w-full p-3 border-gray-200 rounded-full shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <Dropdown
            value={selectedSetor}
            options={setores}
            onChange={(e) => setSelectedSetor(e.value)}
            placeholder="Setor"
            className="w-full p-3 border-gray-200 rounded-full shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Gráfico + Cards */}
        <div className="flex gap-6 mb-6">
          <div className="bg-white p-4 rounded-lg shadow-lg mb-6 max-w-3xl flex-1">
            <h2 className="text-xl font-bold text-gray-800 mb-4">
              Usuários por Diretoria/Área
            </h2>
            <Chart type="bar" data={chartData} style={{ height: "300px" }} />
          </div>

          <div className="flex flex-col gap-4 w-1/3">
            <StatCard
              title="Total de Usuários"
              value={totalUsuarios}
              color="text-blue-600"
              icon={<UsersIcon className="w-6 h-6" />}
            />
            <StatCard
              title="Usuários Ativos"
              value={usuariosAtivos}
              color="text-green-600"
              icon={<UsersIcon className="w-6 h-6" />}
            />
            <StatCard
              title="Bloqueados Temporários"
              value={bloqueadosTemporarios}
              color="text-yellow-500"
              icon={<UsersIcon className="w-6 h-6" />}
            />
            <StatCard
              title="Bloqueados Definitivos"
              value={bloqueadosDefinitivos}
              color="text-red-500"
              icon={<UsersIcon className="w-6 h-6" />}
            />
          </div>
        </div>

        {/* Tabela */}
        <div className="bg-white p-4 rounded-lg shadow-lg">
          <h2 className="text-xl font-bold text-gray-800 mb-4">Usuários</h2>
          <DataTable value={usuarios} responsiveLayout="scroll">
            <Column field="User_ID" header="User_ID" />
            <Column field="Nome" header="Nome" />
            <Column field="Setor" header="Setor" />
            <Column field="Area" header="Área" />
            <Column field="Diretoria" header="Diretoria" />
            <Column field="Descricao" header="Descrição" />
            <Column field="Status" header="Status" />
            <Column field="UltimoAcesso" header="Último Acesso" />
            <Column field="MesesSemAcesso" header="Meses sem Acesso" />
          </DataTable>
        </div>

        {/* Rodapé */}
        <footer className="text-xs text-gray-500 text-center mt-30">
          09-04-2025 | Responsible department for filing: B-QAM | CSD-Class: 0.1
          · Max. 02 years | Internal
        </footer>
      </main>
    </div>
  )
}
