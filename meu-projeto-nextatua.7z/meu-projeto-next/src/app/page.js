// src/App.js
"use client"
import { BrowserRouter as Router, Route, Routes } from "react-router-dom"
import Home from "./pages/Home"
import Estatisticas from "./pages/Estatisticas"
import GerenciamentoUsuarios from "./pages/GerenciamentoUsuarios"
import GerenciamentoEstacoes from "./pages/GerenciamentoEstacoes"

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Estatisticas" element={<Estatisticas />} />
        <Route path="/GerenciamentoUsuarios" element={<GerenciamentoUsuarios />} />
        <Route path="/GerenciamentoEstacoes" element={<GerenciamentoEstacoes />} />
      </Routes>
    </Router>
  )
}

export default App
