/** @type {import('next').NextConfig} */
const nextConfig = {
    typescript: {
        ignoreBuildErrors: true,
     },
     env: {
        //  API_URL: 'http://localhost:8053/',
        API_URL: 'http://vwbrtbsvqa001:8053/',
      },
}

module.exports = nextConfig
