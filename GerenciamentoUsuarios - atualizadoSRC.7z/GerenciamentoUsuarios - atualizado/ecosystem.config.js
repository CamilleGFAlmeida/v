module.exports = {
    apps: [
      {
        exec_mode: 'cluster',
        instances: 2,
        script: 'node_modules/next/dist/bin/next',
        args: 'start',
        watch: true,
        env_dev: {
          name: 'DEV',
          PORT:3000,
          APP_ENV: 'local',
        },
        env_tbt: {
          name: 'FAP_TBT',
          PORT:3053,
          APP_ENV: 'tbt'
        }
      }
    ]
  }