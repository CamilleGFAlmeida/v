export declare namespace Fis {
  
  interface Login {
      login: string | null;
      password: string | null;
      dominio: string | null;
      planta: string | null;
  }

  interface Modificacao {
    solicitante: string | null;
    pedido: string | null;
    grupoDePermissao: string | null;
    nomeDoColaborador: string | null;
    chapa: string | null;
    carterinha:string|null;
    dataalteracao: string|null;
    responsavelAlteracao:string|null;
    
}

}