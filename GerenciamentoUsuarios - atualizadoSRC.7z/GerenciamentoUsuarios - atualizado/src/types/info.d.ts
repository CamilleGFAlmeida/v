export declare namespace AuditZP8 {

    interface Task {
        id: integer | null
        kw: string
        mt_code: string
        filtro: string
        task: string
    }

}