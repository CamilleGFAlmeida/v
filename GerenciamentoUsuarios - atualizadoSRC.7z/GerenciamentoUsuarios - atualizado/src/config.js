import moment from 'moment';

export const monthNames = {
    "01": "Jan", "02": "Fev", "03": "Mar", "04": "Apr", "05": "Mai", "06": "Jun",
    "07": "Jul", "08": "Aug", "09": "Set", "10": "Out", "11": "Nov", "12": "Dez"
}
export const plantas = {
    "53": "Taubaté",
    "51": "Anchieta",
    "57": "Curitiba",
}

export const areas = [
    { name: 'Estamparia', code: 'Q' },
    { name: 'Armação', code: 'B' },
    { name: 'Pintura', code: 'P' },
    { name: 'Montagem Final', code: 'F' },
    { name: 'Peças Compradas', code: 'V' },
];

export const modelos = [
    { name: 'Polo', code: '2G1170' },
    { name: 'SUV', code: '2F6100' },
];

export const getWeeksOfYear = (year) => {
    const weeks = [];
    let startDate = moment(`${year}-01-01`).startOf('week');
    const endDate = moment(`${year}-12-31`).endOf('week');

    while (startDate.isBefore(endDate)) {
        weeks.push({
            weekNumber: startDate.format("YYYY-WW"),
            start: startDate.format('YYYY-MM-DD'),
            end: startDate.endOf('week').format('YYYY-MM-DD')
        });
        startDate.add(1, 'week');
    }

    return weeks;
};