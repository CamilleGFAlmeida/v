'user server'

import pg from 'pg'


export async function Connection(){
    const { Client } = pg
    const client = new Client()
    await client.connect()
    return client;
}