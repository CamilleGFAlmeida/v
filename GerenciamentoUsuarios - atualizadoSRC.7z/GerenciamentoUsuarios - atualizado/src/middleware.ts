import { jwtDecode } from "jwt-decode";
import { type NextRequest } from 'next/server';

export async function middleware(request: NextRequest) {

    //console.log(request);

    //const token = await request.cookies.get('token.fap')?.value

    // console.log(token);

    // if (!token) {
    //     return Response.redirect(new URL('/auth/login', request.url))
    // }

    // interface Token {
    //     iss: string | null;
    //     exp: string | null;
    //     sub: string | null;
    //     rules: { isRoot: boolean, isAdmin: boolean, isEdit: boolean, isView: boolean };
    // }

    //const decoded = jwtDecode<Token>(token);

    // if (!decoded.rules.isRoot && (
    //     request.nextUrl.pathname.startsWith('/cadastro/planta')
    //     || request.nextUrl.pathname.startsWith('/cadastro/escalacao')
    //     || request.nextUrl.pathname.startsWith('/cadastro/indicador')
    //     || request.nextUrl.pathname.startsWith('/cadastro/usuario')
    // )
    // ) {
    //     return Response.redirect(new URL('/auth/access', request.url))
    // }

    // if (!decoded.rules.isAdmin && (
    //     request.nextUrl.pathname.startsWith('/cadastro/grupo')
    //     || request.nextUrl.pathname.startsWith('/cadastro/area')
    //     || request.nextUrl.pathname.startsWith('/cadastro/modelo')
    //     || request.nextUrl.pathname.startsWith('/cadastro/processo')
    // )
    // ) {
    //     return Response.redirect(new URL('/auth/access', request.url))
    // }

    // if (!decoded.rules.isView && (
    //     request.nextUrl.pathname.startsWith('/cadastro/grupo')
    //     || request.nextUrl.pathname.startsWith('/cadastro/area')
    //     || request.nextUrl.pathname.startsWith('/cadastro/modelo')
    //     || request.nextUrl.pathname.startsWith('/cadastro/processo')
    // )
    // ) {
    //     return Response.redirect(new URL('/auth/access', request.url))
    // }

    // if (!decoded.rules.isEdit &&
    //     request.nextUrl.pathname.startsWith('/fap')
    // ) {
    //     return Response.redirect(new URL('/auth/access', request.url))
    // }

}

export const config = {
    matcher: ['/fap/:path*', '/cadastro/:path*', '/dashboard/:path*'],
}


