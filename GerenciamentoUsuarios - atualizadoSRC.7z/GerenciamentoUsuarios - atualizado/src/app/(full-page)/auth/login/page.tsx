/* eslint-disable @next/next/no-img-element */
'use client';
import { logout, setToken } from '@/Service/Auth';
import { useFormik } from 'formik';
import { useRouter } from 'next/navigation';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { Password } from 'primereact/password';
import { ProgressSpinner } from 'primereact/progressspinner';
import { classNames } from 'primereact/utils';
import { useContext, useState } from 'react';
import { LayoutContext } from '../../../../layout/context/layoutcontext';
const LoginPage = () => {
    const { layoutConfig } = useContext(LayoutContext);
    const [statusLogin, setStatusLogin] = useState<Boolean>(false);
    const [erroLogin, setErroLogin] = useState<String>();
    const router = useRouter();




    const containerClassName = classNames('surface-ground flex align-items-center justify-content-center min-h-screen min-w-screen overflow-hidden', { 'p-input-filled': layoutConfig.inputStyle === 'filled' });

    return (
        <div className={containerClassName}>
            <div style={{ display: !statusLogin && "none", width: "100vw", height: "100vh", position: "fixed", top: "0", left: "0", zIndex: "999" }}>
                <div style={{ width: "100vw", height: "100vh", top: "0", left: "0", background: "black", opacity: "0.2" }}></div>
                <ProgressSpinner style={{ width: '50px', height: '50px', position: "absolute", top: "50%", left: "50%" }} strokeWidth="8" />
            </div>
            
                <div>
                   tela de login
                </div>
        </div>
        
    );
};

export default LoginPage;
