'use client';

import { FisService } from "@/Service/FisService";
import { FormEvent, useEffect, useState } from "react";
import { DataTable } from "primereact/datatable";
import { Dropdown } from "primereact/dropdown";
import { Column } from "primereact/column";
import '../permissoes/DataTableDemo.css'

//import '../../../css/DataTableDemo.css'


const fisservice = new FisService()

const Dashboard = () => {
    const [dados, setDados] = useState()
    const [loading, setLoading] = useState(true)
    const [chapa, setChapa] = useState('123456')
    useEffect(() => {
        setLoading(true)

        const p = fisservice.Consultas().then(data => { return data })
        Promise.all([p]).then(function (values) {
            setDados({
                dado: values[0]
            })
        })

        setLoading(false)

    }, [chapa])

    // FUNÇÃO PARA PINTAR A LINHA
    const rowClass = (data) => {
        if (data.RESPONSAVEL === 'qualidade' && data.departamento != 'Qualid.Asseg.') {
            return 'row-accessories'
        }
    }

    // FILTRO PARA ABASTECER A TABELA 
    const filtroPermissoes = dados?.dado?.Permissoes?.filter(item => item['USER_ID'] === chapa.USER_ID)

    console.log(filtroPermissoes);
    

    return (

        <div>
            <div className="justify-content-center pt-2">
                <div className="col-12 text-black-400" >
                    {(dados?.dado?.inicioNumero) ? <p className="m-2 font-bold text-xl"> NOME : {filtroPermissoes[0]?.NAME}</p> : ''}
                    {(dados?.dado?.inicioNumero) ? <p className="m-2 font-bold text-xl"> NUMERO VW :{filtroPermissoes[0]?.USER_ID}</p> : ''}
                    {(dados?.dado?.inicioNumero) ? <p className="m-2 font-bold"> STATUS : {filtroPermissoes[0]?.STATUS}</p> : ''}
                    {(dados?.dado?.inicioNumero) ? <p className="m-2 font-bold"> SITUAÇÃO : {filtroPermissoes[0]?.DESCRICAO}</p> : ''}
                    <Dropdown optionLabel="USER_ID" value={chapa} options={dados?.dado?.inicioNumero} onChange={(e) => setChapa(e.value)} placeholder="Usuários" />
                </div>
                <div className="card">
                    <DataTable value={filtroPermissoes} stripedRows scrollable scrollHeight='60vh' selectionMode='single' rowClassName={rowClass}  >
                        <Column field={"GROUP"} header="GRUPO" sortable style={{ width: '3%' }}></Column>
                        <Column field={"RESPONSAVEL"} header="RESPONSAVEL" sortable style={{ width: '3%' }}></Column>
                        <Column field={"departamento"} header="DEPARTAMENTO" sortable style={{ width: '3%' }}></Column>
                        <Column field={"area"} header="AREA" sortable style={{ width: '3%' }}></Column>
                        <Column field={"GROUP_LAST"} header="ULTIMA ALTERAÇÃO" sortable style={{ width: '3%' }}></Column>
                    </DataTable>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
