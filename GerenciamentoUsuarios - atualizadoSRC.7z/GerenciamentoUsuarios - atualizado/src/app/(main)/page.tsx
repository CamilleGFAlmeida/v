'use client';
import Card from "@/layout/context/card";
import { FisService } from "@/Service/FisService";
import { useEffect, useState } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProgressSpinner } from 'primereact/progressspinner';
import '../css/DataTableDemo.css'

const fisservice = new FisService()

const Dashboard = () => {
    const [dados, setDados] = useState()
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        setLoading(true)
        const p = fisservice.Consultas().then(data => { return data })
        Promise.all([p]).then(function (values) {
            setDados({
                usuarios: values[0]
            })
        })
        setLoading(false)
    }, [])

    const Cor_linha = (row) => {

        if (row?.ULTIMO_ACESSO != null) {
            if (row?.DIF > 3 && row.STATUS === 'ACTIVE') {
                return 'row-accessories'
            } else if (row?.DIF > 3 && row.STATUS === 'INACTIVE') {
                return 'row-accessories_amarelo'
            }
        }
    }

    return (
        <div>
            <div style={{ display: !loading && 'none', width: "100vw", height: "100vh", position: "fixed", top: "0", left: "0", zIndex: "999" }}>
                <div style={{ width: "100vw", height: "100vh", top: "0", left: "0", background: "black", opacity: "0.2" }}></div>
                <ProgressSpinner style={{ width: '50px', height: '50px', position: "absolute", top: "50%", left: "50%" }} strokeWidth="8" />
            </div>

            <div className="grid justify-content-between">
                <Card
                    nome='Usuários Cadastrados'
                    classname='flex align-items-center justify-content-center bg-blue-100 border-round'
                    icon='pi pi-users text-blue-500 text-xl'
                    value={dados?.usuarios?.usuarios.length}
                />

                <Card
                    nome='Usuários Ativos'
                    classname='flex align-items-center justify-content-center bg-green-100 border-round'
                    icon='pi pi-user text-green-500 text-xl'
                    value={dados?.usuarios?.NumeroAtivo.length}
                />

                <Card
                    nome='Bloqueados Temporarios'
                    classname='flex align-items-center justify-content-center bg-orange-100 border-round'
                    icon='pi pi-ban text-red-500 text-xl'
                    value={dados?.usuarios?.NumeroInativo.length}
                />

                <Card
                    nome='Bloqueados Definitivo'
                    classname='flex align-items-center justify-content-center bg-red-100 border-round'
                    icon='pi pi-ban text-red-500 text-xl'
                    value={dados?.usuarios?.NumeroInativoDefintivo.length}
                />

                <div className="text-1xl font-bold justify-content-center pt-3 ">
                    USUÁRIOS ANCHIETA 
                </div>

                <div className="justify-content-center pt-3">
                    <div className="card">
                        <DataTable value={dados?.usuarios?.usuarios} stripedRows scrollable scrollHeight='60vh' selectionMode='single' rowClassName={Cor_linha}  >
                            <Column field={"USER_ID"} header="USER_ID" sortable style={{ width: '3%' }}></Column>
                            <Column field={"NAME"} header="NOME COMPLETO" sortable style={{ width: '3%' }}></Column>
                            <Column field={"setor"} header="SETOR" sortable style={{ width: '3%' }}></Column>
                            <Column field={"area"} header="AREA" sortable style={{ width: '3%' }}></Column>
                            <Column field={"departamento"} header="DIRETORIA" sortable style={{ width: '3%' }}></Column>
                            <Column field={"DESCRICAO"} header="DESCRICAO" sortable style={{ width: '3%' }}></Column>
                            <Column field={"STATUS"} header="STATUS" sortable style={{ width: '3%' }}></Column>
                            <Column field={"ULTIMO_ACESSO"} header="ULTIMO_ACESSO" sortable style={{ width: '3%' }}></Column>
                            <Column field={"DIF"} header="MESES SEM ACESSO" sortable style={{ width: '3%' }}></Column>
                        </DataTable>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
