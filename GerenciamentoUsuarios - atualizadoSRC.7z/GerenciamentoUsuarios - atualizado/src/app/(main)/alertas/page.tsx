'use client';

import { FisService } from "@/Service/FisService";
import { useEffect, useState } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProgressSpinner } from 'primereact/progressspinner';
import moment from "moment";
import DataFrame from "dataframe-js"

const fisservice = new FisService()

const Alerta = () => {
    const [dados, setDados] = useState()
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        setLoading(true)
        const p = fisservice.Consultas().then(data => { return data })
        Promise.all([p]).then(function (values) {
            setDados({
                dado: values[0]
            })
        })
        setLoading(false)

    }, [])

    console.log(dados?.dado?.usuariosMaior3Inativo);



    return (
        <div className="p-2">
            <div style={{ display: !loading && "none", width: "100vw", height: "100vh", position: "fixed", top: "0", left: "0", zIndex: "999" }}>
                <div style={{ width: "100vw", height: "100vh", top: "0", left: "0", background: "black", opacity: "0.2" }}></div>
                <ProgressSpinner style={{ width: '50px', height: '50px', position: "absolute", top: "50%", left: "50%" }} strokeWidth="8" />
            </div>
            <div>
                <h1>Alerta de usuários </h1>
                <div className="flex gap-1">
                    <div className="justify-content-center pt-3">
                        <span className="text-lg font-bold ">USUÁRIOS BLOQUEADOS COM MAIS DE 3 MESES DE INATIVIDADE</span>
                        <div className="card">
                            <DataTable value={dados?.dado?.usuariosMaior3Inativo} stripedRows scrollable scrollHeight='60vh' selectionMode='single'  >
                                <Column field={"USER_ID"} header="USER_ID" sortable style={{ width: '3%' }}></Column>
                                <Column field={"NAME"} header="NOME COMPLETO" sortable style={{ width: '3%' }}></Column>
                                <Column field={"area"} header="AREA" sortable style={{ width: '3%' }}></Column>
                                <Column field={"ULTIMO_ACESSO"} header="ULTIMO_ACESSO" sortable style={{ width: '3%' }}></Column>
                                <Column field={"DIF"} header="MESES SEM USO" sortable style={{ width: '3%' }}></Column>
                            </DataTable>
                        </div>
                    </div>
                    <div className="justify-content-center pt-3">
                        <span className="text-lg font-bold ">USUÁRIOS BLOQUEADOS COM MAIS DE 3 MESES DE INATIVIDADE</span>
                        <div className="card">
                            <DataTable value={dados?.dado?.usuariosMaior3Ativo} stripedRows scrollable scrollHeight='60vh' selectionMode='single'  >
                                <Column field={"USER_ID"} header="USER_ID" sortable style={{ width: '3%' }}></Column>
                                <Column field={"NAME"} header="NOME COMPLETO" sortable style={{ width: '3%' }}></Column>
                                <Column field={"area"} header="AREA" sortable style={{ width: '3%' }}></Column>
                                <Column field={"ULTIMO_ACESSO"} header="ULTIMO_ACESSO" sortable style={{ width: '3%' }}></Column>
                                <Column field={"DIF"} header="MESES SEM USO" sortable style={{ width: '3%' }}></Column>
                            </DataTable>
                        </div>
                    </div>
                    <div className="justify-content-center pt-3">
                        <span className="text-lg font-bold ">USUÁRIOS SEM REGISTROS DO ÚLTIMO ACESSO </span>
                        <div className="card">
                            <DataTable value={dados?.dado?.usuariosNull} stripedRows scrollable scrollHeight='60vh' selectionMode='single'>
                                <Column field={"USER_ID"} header="USER_ID" sortable style={{ width: '3%' }}></Column>
                                <Column field={"NAME"} header="NOME COMPLETO" sortable style={{ width: '3%' }}></Column>
                                <Column field={"area"} header="AREA" sortable style={{ width: '3%' }}></Column>
                                <Column field={"MESES"} header="MESES SEM ACESSO" sortable style={{ width: '2%' }}></Column>
                            </DataTable>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    );
};

export default Alerta;
