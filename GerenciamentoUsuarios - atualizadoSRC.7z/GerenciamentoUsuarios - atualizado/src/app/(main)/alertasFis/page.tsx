'use client';

import { FisService } from "@/Service/FisService";
import { useEffect, useState } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import moment from "moment";


const fisservice = new FisService()

const Alerta = () => {
    const [dados, setDados] = useState()
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        // setLoading(true)
        const u = fisservice.getResultadoM800().then(data => { return data })
        const p = fisservice.getV900SemM800().then(data => { return data })

        Promise.all([u, p]).then(function (values) {
            setDados({
                resultM800: values[0],
                V900: values[1]
            })
        })
        // setLoading(false)
    }, [])

    return (
        <div className="">
            <div className="justify-content-center pt-3">
                <span className="text-lg font-bold ">CARROS COM V900 SEM M800</span>
                <div className="card">
                    <DataTable value={dados?.V900} stripedRows scrollable scrollHeight='60vh' selectionMode='single'  >
                        <Column field={"MODELO"} header="MODELO" sortable style={{ width: '3%' }}></Column>
                        <Column field={"CHASSI"} header="CHASSI" sortable style={{ width: '3%' }}></Column>
                        <Column field={"STATUS"} header="ULTIMO STATUS" sortable style={{ width: '3%' }}></Column>
                        <Column field={"DATA"} header="DATA" sortable style={{ width: '3%' }}></Column>
                        <Column field={"OK_RODAGEM"} header="OK_RODAGEM" sortable style={{ width: '3%' }}></Column>
                        <Column field={"OK_AGUA"} header="OK_AGUA" sortable style={{ width: '3%' }}></Column>
                    </DataTable>
                </div>
            </div>
            <div className="justify-content-center pt-3">
                <span className="text-lg font-bold ">RESULTADOS RECEBIDO APÓS M800</span>
                <div className="card">
                    <DataTable value={dados?.resultM800} stripedRows scrollable scrollHeight='60vh' selectionMode='single'  >
                        <Column field={"MODELO"} header="MODELO" sortable style={{ width: '3%' }}></Column>
                        <Column field={"CHASSI_CURTO"} header="CHASSI" sortable style={{ width: '3%' }}></Column>
                        <Column field={"STATUS"} header="RESULTADO" sortable style={{ width: '3%' }}></Column>
                        <Column field={"RESULT_ID"} header="ID_RESULTADO" sortable style={{ width: '3%' }}></Column>
                        <Column field={"RESULT_DESCRIPTION"} header="RESULTADO" sortable style={{ width: '3%' }}></Column>
                        <Column field={"TIME_RESULT"} header="DATA RESULTADO" sortable style={{ width: '3%' }}></Column>
                        <Column field={"TIME_STATUS"} header="DATA STATUS" sortable style={{ width: '3%' }}></Column>
                        <Column field={"DELTA"} header="DIFERENÇA DE TEMPO(SEGUNDOS)" sortable style={{ width: '3%' }}></Column>
                    </DataTable>
                </div>
            </div>

        </div>
    );
};

export default Alerta;
