'use client';
import { FisService } from "@/Service/FisService";
import { useEffect, useState } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";


const fisservice = new FisService()

const Estatistica = () => {
    const [dados, setDados] = useState()
    const [loading, setLoading] = useState(false)

    useEffect(() => {
        setLoading(true)
        const p = fisservice.Consultas().then(data => { return data })
        Promise.all([p]).then(function (values) {
            setDados({
                dado: values[0]
            })
        })
        setLoading(false)

    }, [])

    return (
        <div>

            <div className="text-4xl font-bold justify-content-center">ESTATÍSTICA</div>
            <div className="justify-content-center pt-3 gap-2 flex">
                <div className="text-justify" >
                    <div className="2xl font-bold text-center pt-3">QTD POR DIRETORIA</div>
                    <div className="card">
                        <DataTable value={dados?.dado?.qtd_departamento} stripedRows scrollable scrollHeight='70vh' selectionMode='single'>
                            <Column field={"departamento"} header="DIRETORIA" sortable style={{ width: '3%' }}></Column>
                            <Column field={"qtd"} header="QTD" sortable style={{ width: '2%' }}></Column>
                        </DataTable>
                    </div>
                </div>
                <div>
                    <div className="2xl font-bold text-center pt-3">QTD POR SETOR</div>
                    <div className="card">
                        <DataTable value={dados?.dado?.qtd_setor} stripedRows scrollable scrollHeight='70vh' selectionMode='single'>
                            <Column field={"area"} header="SETOR" sortable style={{ width: '10%' }}></Column>
                            <Column field={"qtd"} header="QTD" sortable style={{ width: '2%' }}></Column>
                        </DataTable>
                    </div>
                </div>

                <div>
                    <div className="2xl font-bold text-center pt-3">DESLIGADOS</div>
                    <div className="card">
                        <DataTable value={dados?.dado?.nome_demitidos} stripedRows scrollable scrollHeight='70vh' selectionMode='single'>
                            <Column field={"USER_ID"} header="CHAPA" sortable style={{ width: '10%' }}></Column>
                            <Column field={"NAME"} header="NOME" sortable style={{ width: '10%' }}></Column>

                        </DataTable>
                    </div>
                </div>
                <div>
                    <div className="2xl font-bold text-center pt-3">BLOQUEADOS</div>
                    <div className="card">
                        <DataTable value={dados?.dado?.nome_bloqueados} stripedRows scrollable scrollHeight='70vh' selectionMode='single'>
                            <Column field={"USER_ID"} header="CHAPA" sortable style={{ width: '7%' }}></Column>
                            <Column field={"NAME"} header="NOME" sortable style={{ width: '10%' }}></Column>
                        </DataTable>
                    </div>
                </div>

                <div>
                    <div className="2xl font-bold text-center pt-3">NÃO ENCONTRADO</div>
                    <div className="card">
                        <DataTable value={dados?.dado?.nome_NaoEncontrado} stripedRows scrollable scrollHeight='70vh' selectionMode='single'>
                            <Column field={"USER_ID"} header="CHAPA" sortable style={{ width: '3%' }}></Column>
                            <Column field={"NAME"} header="NOME" sortable style={{ width: '7%' }}></Column>
                            <Column field={"DESCRICAO"} header="DESCRICAO" sortable style={{ width: '2%' }}></Column>
                        </DataTable>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Estatistica