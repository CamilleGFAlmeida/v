'use client';
import Card from "@/layout/context/card";
import { FisService } from "@/Service/FisService";
import { useEffect, useState } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";

const fisservice = new FisService()

const Estacoes = () => {

  const [dados, setDados] = useState()
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // setLoading(true)
    const u = fisservice.getestacoes().then(data => { return data })
    Promise.all([u]).then(function (values) {
      setDados({
        estacao: values[0]
      })
    })
    // setLoading(false)
  }, [])


  //console.log(dados);
  

  return (
    <div>
      <div className="text-4xl font-bold justify-content-center ">ESTAÇÕES ANCHIETA</div>
      <div className="justify-content-center pt-3">
        <div className="card">
          <DataTable value={dados?.estacao} stripedRows scrollable scrollHeight='70vh' selectionMode='single'>
            <Column field={"ESTACAO"} header="ESTACAO" sortable style={{ width: '3%' }}></Column>
            <Column field={"ALA"} header="ALA" sortable style={{ width: '3%' }}></Column>
            <Column field={"AREA"} header="AREA" sortable style={{ width: '3%' }}></Column>
            <Column field={"LOCAL"} header="LOCAL" sortable style={{ width: '3%' }}></Column>
            <Column field={"RESPO"} header="RESPO" sortable style={{ width: '3%' }}></Column>
            <Column field={"TIPO"} header="TIPO" sortable style={{ width: '3%' }}></Column>
            <Column field={"STATUS"} header="STATUS" sortable style={{ width: '3%' }}></Column>
          </DataTable>
        </div>

      </div>
    </div>


  );
};

export default Estacoes;
