import AppMenu from './AppMenu';

const AppSidebar = () => {
    return <AppMenu />;
};

export default AppSidebar;
