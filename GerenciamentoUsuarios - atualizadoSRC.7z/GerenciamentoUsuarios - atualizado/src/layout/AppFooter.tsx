/* eslint-disable @next/next/no-img-element */
import moment from 'moment'
import React, { useContext } from 'react';
import { LayoutContext } from './context/layoutcontext';

const AppFooter = () => {
    const { layoutConfig } = useContext(LayoutContext);

    return (
        <div className="layout-footer">
             {moment().format("DD-MM-yy")} | Responsible department for filing: B-QAM | CSD-Class: 0.1 - Max. 02 years | Internal
        </div>
    );
};

export default AppFooter;
