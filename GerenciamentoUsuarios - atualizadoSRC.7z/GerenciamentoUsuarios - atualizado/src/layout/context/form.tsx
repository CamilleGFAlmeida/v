 'use client'
export function AddBusca(){
    // function handleBusca(form:FormData) {
    //     'use server'

    //     console.log(form.entries());        
        
    // }

    return(
        <form action = {handleBusca}>
            <input type="text" name='chapa'placeholder="Chapa" />
            <button type="submit">Buscar</button>
        </form>
    )
}