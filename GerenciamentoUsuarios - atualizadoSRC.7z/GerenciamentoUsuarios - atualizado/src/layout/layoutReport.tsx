/* eslint-disable react-hooks/exhaustive-deps */
'use client';

import { ChildContainerProps } from '@/types';
import React from 'react';

const LayoutReport = ({ children }: ChildContainerProps) => {
    return (
        <React.Fragment>
            <div >
                <div className="layout-report-container">
                    <div className="layout-main">{children}</div>
                </div>
            </div>
        </React.Fragment>
    );
};

export default LayoutReport;