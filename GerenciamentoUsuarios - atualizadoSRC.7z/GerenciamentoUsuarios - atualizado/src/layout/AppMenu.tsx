/* eslint-disable @next/next/no-img-element */

import { AppMenuItem } from '@/types';
import { useContext } from 'react';
import AppMenuitem from './AppMenuitem';
import { LayoutContext } from './context/layoutcontext';
import { MenuProvider } from './context/menucontext';

const AppMenu = () => {
    const { layoutConfig } = useContext(LayoutContext);

    const model: AppMenuItem[] = [
        {
            label: 'Usuários',
            items: [{
                label: 'Usuários',
                icon: 'pi pi-fw pi-home',
                to: '/'
            },           
            {
                label: 'Permissões',
                icon: 'pi pi-fw pi-building',
                to: '/permissoes'
            },
            {
                label: 'Estatistica',
                icon: 'pi pi-fw pi-building',
                to: '/estatistica'
            }           
            
            ],

        },
        {
            label: 'Estações',
            icon: 'pi pi-fw pi-briefcase',
            to: '/',
            items: [
                {
                    label: 'Estações',
                    icon: 'pi pi-fw pi-building',
                    to: '/estacoes'
                },
            ]
        },
        {
            label: 'Alertas',
            icon: 'pi pi-fw pi-briefcase',
            to: '/',
            items: [
                {
                    label: 'Alertas Usuários',
                    icon: 'pi pi-fw pi-building',
                    to: '/alertas'
                },
                {
                    label: 'Alertas FIS',
                    icon: 'pi pi-fw pi-building',
                    to: '/alertasFis'
                }
            ]
        },
    ];

    return (
        <MenuProvider>
            <ul className="layout-menu">
                {model.map((item, i) => {
                    return !item?.seperator ? <AppMenuitem item={item} root={true} index={i} key={item.label} /> : <li className="menu-separator"></li>;
                })}
            </ul>
        </MenuProvider>
    );
};

export default AppMenu;
