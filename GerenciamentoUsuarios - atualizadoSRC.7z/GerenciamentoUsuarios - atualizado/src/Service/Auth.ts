import axios, { AxiosResponse } from 'axios';
import { parseCookies, setCookie } from 'nookies';

const responseBody = (response: AxiosResponse) => response?.data;
export const TOKEN_KEY: string = "token.fap";

export const isAuthenticated = () => true;
export const setToken = (token: string) => setCookie(undefined, TOKEN_KEY, token, { maxAge: 60 * 60 * 1, path: '/' });
export const logout = () => setCookie(undefined, TOKEN_KEY, "", { maxAge: 0, path: '/' });
export const getToken = () => { const { 'token.fap': token } = parseCookies(); return token; };


const getInstance = () => axios.create({
  // baseURL: "http://localhost:8090/",
  //baseURL: "http://10.134.244.74:8073/",
  timeout: 15000,
  headers: {
    'Authorization': 'Bearer ' + getToken()
  }
});

const err = (e: { response: { status: number; }; }) => {
  if (e?.response?.status === 403) {
    //logout();
  }
};

export const requests = () => {

  return (
    {
      get: (url: string) => getInstance().get(url).then(responseBody).catch((error) => { err(error) }),
      post: (url: string, body: {}) => getInstance().post(url, body).then(responseBody).catch((error) => { err(error) }),
      put: (url: string, body: {}) => getInstance().put(url, body).then(responseBody).catch((error) => { err(error) }),
      delete: (url: string) => getInstance().delete(url).then(responseBody).catch((error) => { err(error) }),
    }
  );
};