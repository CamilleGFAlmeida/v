"user client"

import axios from 'axios';


//const URL = "http://10.135.161.9:8090/51/";
const URL ="http://127.0.0.1:8080/51/"


export class FisService{

async getusuarios() {  
  let post = { 'api': 'topic1' }   
  return await axios.post(URL + "gere_usuarios", post)
      .then(res => res.data)
      .catch(error => {
          console.error('Error', error);
      });
}

async getestacoes() {
  let post = { 'api': 'estacoes' }
  return await axios.post(URL + "gere_usuarios", post)
      .then(res => res.data)
      .catch(error => {
          console.error('Error', error);
      });
}

async getPermissoes() {
    let post = { 'api': 'Permissoes' }
    return await axios.post(URL + "gere_usuarios", post)
        .then(res => res.data)
        .catch(error => {
            console.error('Error', error);
        });
  }
  async getV900SemM800() {
    let post = { 'api': 'statusv900sem800' }
    return await axios.post(URL + "gere_usuarios", post)
        .then(res => res.data)
        .catch(error => {
            console.error('Error', error);
        });
  }
  async getResultadoM800() {
    let post = { 'api': 'resultadoM800' }
    return await axios.post(URL + "gere_usuarios", post)
        .then(res => res.data)
        .catch(error => {
            console.error('Error', error);
        });
  }

  async Consultas() {
    let post = { 'api': 'Consulta' }
    return await axios.post(URL + "gere_usuarios", post)
        .then(res => res.data)
        .catch(error => {
            console.error('Error', error);
        });
  }
  
  }




