import React, { useState } from "react"
import { HomeIcon, BarChartIcon, SettingsIcon, UsersIcon, LogOutIcon, RefreshCwIcon} from 'lucide-react'  // Importando os ícones
import { Dropdown } from "primereact/dropdown"
import { Button } from "primereact/button"
import { Chart } from "primereact/chart"
import { DataTable } from "primereact/datatable"
import { Column } from "primereact/column"

export default function Home() {
  const [selectedResponsavel, setSelectedResponsavel] = useState(null)
  const [selectedArea, setSelectedArea] = useState(null)
  const [selectedSetor, setSelectedSetor] = useState(null)

  const responsaveis = [{ label: "Responsável", value: null }]
  const areas = [{ label: "Área", value: null }]
  const setores = [{ label: "Setor", value: null }]

  const usuarios = [
    {
      User_ID: "444444",
      Nome: "Everton",
      Setor: "QA Processos",
      Area: "TI",
      Diretoria: "Tito Jorge",
      Descricao: "TI",
      Status: "Ativo",
      UltimoAcesso: "04/04/2025",
      MesesSemAcesso: 0,
    },
    {
      User_ID: "444445",
      Nome: "Maria",
      Setor: "QA Processos",
      Area: "TI",
      Diretoria: "Tito Jorge",
      Descricao: "TI",
      Status: "Bloqueado Temporário",
      UltimoAcesso: "03/03/2025",
      MesesSemAcesso: 1,
    },
    {
      User_ID: "444446",
      Nome: "João",
      Setor: "QA Processos",
      Area: "TI",
      Diretoria: "Tito Jorge",
      Descricao: "TI",
      Status: "Bloqueado Definitivo",
      UltimoAcesso: "02/02/2025",
      MesesSemAcesso: 2,
    },
  ]

  const chartData = {
    labels: ["TEC", "PROD", "RH", "QUA", "LOG", "MAN", "ENG", "ADM"],
    datasets: [
      {
        label: "Usuários",
        data: [200, 300, 250, 400, 500, 450, 600, 700],
        backgroundColor: "#3B82F6",
      },
    ],
  }

  const MenuItem = ({ icon: Icon, label, selected }) => (
    <div
      className={`flex items-center gap-3 px-4 py-2 rounded-lg cursor-pointer transition-all duration-200 ease-in-out transform ${
        selected
          ? "bg-blue-600 text-white shadow-md scale-105"
          : "text-gray-700 hover:bg-blue-100 hover:text-blue-500"
      }`}
    >
      <Icon size={20} />
      <span>{label}</span>
    </div>
  )

  // Funções para contar os diferentes tipos de status de usuário
  const totalUsuarios = usuarios.length
  const usuariosAtivos = usuarios.filter(user => user.Status === "Ativo").length
  const bloqueadosTemporarios = usuarios.filter(user => user.Status === "Bloqueado Temporário").length
  const bloqueadosDefinitivos = usuarios.filter(user => user.Status === "Bloqueado Definitivo").length

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="w-72 bg-white text-gray-700 p-6 flex flex-col justify-between">
        <div>
          <div className="mb-8">
            <img
              src="/assets/logo-vw.png"
              alt="Logo"
              className="w-10 h-10 mx-auto"
            />
          </div>
          <nav className="space-y-6">
            <MenuItem icon={BarChartIcon} label="Estatísticas" />
            <MenuItem icon={HomeIcon} label="Estações" />
            <MenuItem icon={UsersIcon} label="Usuários" />
            <div className="mt-8 text-gray-700 text-sm font-semibold">Alertas</div>
            <MenuItem icon={UsersIcon} label="Usuários" />
            <MenuItem icon={SettingsIcon} label="FIS" />
            <div className="mt-8 text-gray-700 text-sm font-semibold">Alterações</div>
            <MenuItem icon={UsersIcon} label="Usuários" />
            <MenuItem icon={RefreshCwIcon} label="Permissões" />
          </nav>
        </div>

        <button className="font-semibold text-left text-sm text-gray-600 hover:text-blue-600 flex items-center gap-3 mt-6">
          <LogOutIcon size={20} />
          Sair
        </button>
      </aside>

      {/* Conteúdo principal */}
      <main className="flex-1 p-6 bg-gray-50">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-xl font-bold text-gray-800">Início</h1>
          <Button
            label="Download"
            icon="pi pi-download"
            className="p-button-outlined text-gray-600 hover:text-gray-800"
          />
        </div>

        {/* Filtros (Dropdowns) */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <Dropdown
            value={selectedResponsavel}
            options={responsaveis}
            onChange={(e) => setSelectedResponsavel(e.value)}
            placeholder="Responsável"
            className="w-full p-3 border-gray-200 rounded-full shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <Dropdown
            value={selectedArea}
            options={areas}
            onChange={(e) => setSelectedArea(e.value)}
            placeholder="Área"
            className="w-full p-3 border-gray-200 rounded-full shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <Dropdown
            value={selectedSetor}
            options={setores}
            onChange={(e) => setSelectedSetor(e.value)}
            placeholder="Setor"
            className="w-full p-3 border-gray-200 rounded-full shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Layout com gráfico à esquerda e cards à direita */}
        <div className="flex gap-6 mb-6">
          {/* Gráfico */}
          <div className="bg-white p-4 rounded-lg shadow-lg mb-6 max-w-3xl flex-1">
            <h2 className="text-xl font-bold text-gray-800 mb-4">
              Usuários por Diretoria/Área
            </h2>
            <Chart type="bar" data={chartData} style={{ height: "300px" }} />
          </div>

          {/* Cards no lado direito */}
          <div className="flex flex-col gap-4 w-1/3">
            <div className="bg-white p-4 rounded-lg shadow-lg">
              <h3 className="text-lg font-semibold text-gray-700">Total de Usuários</h3>
              <p className="text-2xl text-gray-800">{totalUsuarios}</p>
            </div>
            <div className="bg-white p-4 rounded-lg shadow-lg">
              <h3 className="text-lg font-semibold text-gray-700">Usuários Ativos</h3>
              <p className="text-2xl text-green-600">{usuariosAtivos}</p>
            </div>
            <div className="bg-white p-4 rounded-lg shadow-lg">
              <h3 className="text-lg font-semibold text-gray-700">Bloqueados Temporários</h3>
              <p className="text-2xl text-yellow-600">{bloqueadosTemporarios}</p>
            </div>
            <div className="bg-white p-4 rounded-lg shadow-lg">
              <h3 className="text-lg font-semibold text-gray-700">Bloqueados Definitivos</h3>
              <p className="text-2xl text-red-600">{bloqueadosDefinitivos}</p>
            </div>
          </div>
        </div>

        {/* Tabela */}
        <div className="bg-white p-4 rounded-lg shadow-lg">
          <h2 className="text-xl font-bold text-gray-800 mb-4">Usuários</h2>
          <DataTable value={usuarios} responsiveLayout="scroll">
            <Column field="User_ID" header="User_ID" />
            <Column field="Nome" header="Nome" />
            <Column field="Setor" header="Setor" />
            <Column field="Area" header="Área" />
            <Column field="Diretoria" header="Diretoria" />
            <Column field="Descricao" header="Descrição" />
            <Column field="Status" header="Status" />
            <Column field="UltimoAcesso" header="Último Acesso" />
            <Column field="MesesSemAcesso" header="Meses sem Acesso" />
          </DataTable>
        </div>

        {/* Rodapé */}
        <footer className="text-xs text-gray-500 mt-12">
          09-04-2025 | Responsible department for filing: B-QAM | CSD-Class:
          0.1 · Max. 02 years | Internal
        </footer>
      </main>
    </div>
  )
}
