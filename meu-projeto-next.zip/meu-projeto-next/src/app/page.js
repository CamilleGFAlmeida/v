// src/App.js
"use client"
import { BrowserRouter as Router, Route, Routes } from "react-router-dom"
import Home from "./pages/Home"
import Estatisticas from "./pages/Estatisticas"

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Estatisticas" element={<Estatisticas />} />
      </Routes>
    </Router>
  )
}

export default App
