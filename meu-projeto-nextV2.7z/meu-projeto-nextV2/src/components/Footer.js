// components/Footer.js
import React from "react"

export default function Footer() {
  return (
    <footer className="text-xs text-gray-500 text-center mt-20">
      Responsible department for filing: B-QAM | CSD-Class: 0.1 · Max. 02 years | Internal
    </footer>
  )
}
