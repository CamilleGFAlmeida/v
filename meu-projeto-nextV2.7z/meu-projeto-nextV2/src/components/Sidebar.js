// Sidebar.js
import React from "react"
import { Link, useLocation } from "react-router-dom"
import { HomeIcon, BarChartIcon, UsersIcon, SettingsIcon, LogOutIcon, RefreshCwIcon } from "lucide-react"

const Sidebar = () => {
  const location = useLocation()

  const MenuItem = ({ icon: Icon, label, selected, to }) => (
    <Link to={to}>
      <div
        className={`p-2 rounded-md cursor-pointer flex items-center gap-2 ${
          selected
            ? "bg-blue-100 text-blue-600 font-semibold"
            : "text-gray-600 hover:bg-blue-100 hover:text-blue-600"
        }`}
      >
        <Icon size={20} />
        {label}
      </div>
    </Link>
  )

  return (
    <aside className="w-60 bg-white shadow-md p-5 flex flex-col justify-between">
      <div>
        <div className="mb-8">
          <Link to="/"><img src="/assets/logo-vw.png" alt="Logo" className="w-8 h-8 cursor pointer" /></Link>
        </div>

        <nav className="flex flex-col gap-6">
          {/* Menu Principal */}
          <div className="flex flex-col gap-4">
            <MenuItem
              icon={BarChartIcon}
              label="Estatísticas"
              selected={location.pathname === "/Estatisticas"}
              to="/Estatisticas"
            />
            <MenuItem
              icon={HomeIcon}
              label="Estações"
              selected={location.pathname === "/Estacoes"}
              to="/Estacoes"
            />
            <MenuItem
              icon={UsersIcon}
              label="Usuários"
              selected={location.pathname === "/GerenciamentoUsuarios"}
              to="/GerenciamentoUsuarios"
            />
          </div>

          {/* Alertas */}
          <div className="flex flex-col gap-4">
            <div className="mt-3 text-gray-700 text-sm font-semibold">Alertas</div>
            <MenuItem
              icon={UsersIcon}
              label="Usuários"
              selected={location.pathname === "/AlertasUsuarios"}
              to="/AlertasUsuarios"
            />
            <MenuItem
              icon={SettingsIcon}
              label="FIS"
              selected={location.pathname === "/AlertasFIS"}
              to="/AlertasFIS"
            />
          </div>

          {/* Alterações */}
          <div className="flex flex-col gap-4">
            <div className="mt-3 text-gray-700 text-sm font-semibold">Alterações</div>
            <MenuItem
              icon={UsersIcon}
              label="Usuários"
              selected={location.pathname === "/AlteracoesUsuarios"}
              to="/AlteracoesUsuarios"
            />
            <MenuItem
              icon={RefreshCwIcon}
              label="Permissões"
              selected={location.pathname === "/AlteracoesPermissoes"}
              to="/AlteracoesPermissoes"
            />
          </div>
        </nav>
      </div>

      {/* Botão Sair */}
      <button className="font-semibold text-left text-sm text-gray-600 hover:text-blue-600 flex items-center gap-3 mt-6">
        <LogOutIcon size={20} />
        Sair
      </button>
    </aside>
  )
}

export default Sidebar
