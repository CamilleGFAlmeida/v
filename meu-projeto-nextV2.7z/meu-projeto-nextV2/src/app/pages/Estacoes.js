import React, { useState, useMemo, useEffect } from "react";
import { InputText } from "primereact/inputtext";
import { Dropdown } from "primereact/dropdown";
import { Button } from "primereact/button";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { LogOutIcon, HomeIcon, BarChartIcon, UsersIcon, SettingsIcon, RefreshCwIcon } from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import Footer from "components/Footer"
import Sidebar from "components/Sidebar";

// Dados simulados para as estações
const estacoes = [
  {
    id: "EST001",
    tipo: "FIS Manual",
    local: "Prédio A",
    area: "Área 1",
    responsavel: "João Silva",
    status: "Ativa",
    ala: "Ala 14",
  },
  {
    id: "EST002",
    tipo: "FIS Automática",
    local: "Prédio B",
    area: "Área 2",
    responsavel: "Maria Oliveira",
    status: "Inativa",
    ala: "Ala 7",
  },
  {
    id: "EST003",
    tipo: "FIS Semi-Automática",
    local: "Prédio C",
    area: "Área 1",
    responsavel: "Carlos Lima",
    status: "Manutenção",
    ala: "Ala 5",
  },
];

// Componente para os itens do menu da Sidebar
const MenuItem = ({ icon: Icon, label, selected }) => (
  <div
    className={`p-2 rounded-md cursor-pointer flex items-center gap-2 ${
      selected
        ? "bg-blue-100 text-blue-600 font-semibold"
        : "text-gray-600 hover:bg-blue-100 hover:text-blue-600"
    }`}
  >
    <Icon size={20} />
    {label}
  </div>
);

export default function Estacoes() {
  const [filtros, setFiltros] = useState({
    area: null,
    responsavel: null,
    local: null,
    ala: null,
    busca: "",
  });

  const [isClient, setIsClient] = useState(false);
  const location = useLocation();  // Usando o useLocation para determinar o caminho atual

  useEffect(() => {
    setIsClient(true); // Definir que estamos no lado do cliente
  }, []);

  // Função para gerar as opções dos filtros
  const gerarOpcoes = (campo) => {
    const unicos = [...new Set(estacoes.map((e) => e[campo]))];
    return unicos.map((v) => ({ label: v, value: v }));
  };

  // Função para aplicar os filtros
  const estacoesFiltradas = useMemo(() => {
    return estacoes.filter((e) => {
      const condicoes = [
        !filtros.area || e.area === filtros.area,
        !filtros.responsavel || e.responsavel === filtros.responsavel,
        !filtros.local || e.local === filtros.local,
        !filtros.ala || e.ala === filtros.ala,
        !filtros.busca ||
          e.id.toLowerCase().includes(filtros.busca.toLowerCase()) ||
          e.responsavel.toLowerCase().includes(filtros.busca.toLowerCase()),
      ];
      return condicoes.every(Boolean);
    });
  }, [filtros]);

  // Função para limpar os filtros
  const limparFiltros = () => {
    setFiltros({
      area: null,
      responsavel: null,
      local: null,
      ala: null,
      busca: "",
    });
  };

  if (!isClient) {
    return null;
  }

  return (
    <div className="flex min-h-screen bg-[#F9F9F9] text-[#1C1C1C]">
      {/* Sidebar */}
      <Sidebar /> 

      {/* Main content */}
      <div className="flex-1 p-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-semibold">Gerenciamento de Estações FIS</h1>
          <Button
            label="Download"
            icon="pi pi-download"
            className="p-button-outlined text-gray-600 hover:text-gray-800"
          />
        </div>

        {/* Filtros */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-5 mb-6">
          <Dropdown
            value={filtros.area}
            options={gerarOpcoes("area")}
            onChange={(e) => setFiltros({ ...filtros, area: e.value })}
            placeholder="Área"
            className="w-full p-3 border-gray-300 rounded-full shadow-sm"
          />
          <Dropdown
            value={filtros.responsavel}
            options={gerarOpcoes("responsavel")}
            onChange={(e) => setFiltros({ ...filtros, responsavel: e.value })}
            placeholder="Responsável"
            className="w-full p-3 border-gray-300 rounded-full shadow-sm"
          />
          <Dropdown
            value={filtros.local}
            options={gerarOpcoes("local")}
            onChange={(e) => setFiltros({ ...filtros, local: e.value })}
            placeholder="Local"
            className="w-full p-3 border-gray-300 rounded-full shadow-sm"
          />
          <Dropdown
            value={filtros.ala}
            options={gerarOpcoes("ala")}
            onChange={(e) => setFiltros({ ...filtros, ala: e.value })}
            placeholder="Ala"
            className="w-full p-3 border-gray-300 rounded-full shadow-sm"
          />
        </div>

        {/* Busca */}
        <div className="mb-6">
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            Busca por Nome ou ID
          </label>
          <InputText
            value={filtros.busca}
            onChange={(e) => setFiltros({ ...filtros, busca: e.target.value })}
            className="w-full rounded-full bg-white mt-3 py-3 shadow-sm text-gray-700"
          />
        </div>

        {/* Botão Limpar Filtros */}
        <Button
          label="Limpar Filtros"
          icon="pi pi-refresh"
          className="p-button-outlined p-button-text text-gray-600 hover:text-gray-800 mb-6"
          onClick={limparFiltros}
        />

        {/* Título da Tabela */}
        <h2 className="text-xl font-semibold mb-2 py-4">Estações</h2>

        {/* Tabela */}
        <div className="bg-white rounded-xl shadow p-4">
          <DataTable value={estacoesFiltradas} emptyMessage="Nenhuma estação encontrada.">
            <Column field="id" header="Estação_ID" />
            <Column field="tipo" header="Tipo da Estação" />
            <Column field="local" header="Local" />
            <Column field="area" header="Área" />
            <Column field="responsavel" header="Responsável" />
            <Column field="status" header="Status" />
            <Column field="ala" header="Ala" />
          </DataTable>
        </div>

        {/* Rodapé */}
        <Footer /> 
      </div>
    </div>
  );
}
