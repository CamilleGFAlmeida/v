"use client"

import React, { useState } from "react"
import {
  BarChartIcon,
  HomeIcon,
  LogOutIcon,
  SettingsIcon,
  UsersIcon,
  RefreshCwIcon,
} from "lucide-react"
import { Link, useLocation } from "react-router-dom"
import { InputText } from "primereact/inputtext"
import { Dropdown } from "primereact/dropdown"
import { Button } from "primereact/button"
import { Dialog } from "primereact/dialog"
import { Tag } from "primereact/tag"
import { Calendar } from "primereact/calendar"
import "primereact/resources/themes/saga-blue/theme.css"
import "primereact/resources/primereact.min.css"
import "primeicons/primeicons.css"
import Footer from "components/Footer"
import Sidebar from "components/Sidebar"

const GerenciamentoUsuarios = () => {
  const location = useLocation()
  const [visible, setVisible] = useState(false)
  const [dataFiltroHistorico, setDataFiltroHistorico] = useState(null)

  const [filtros, setFiltros] = useState({
    grupo: null,
    responsavel: null,
    departamento: null,
    area: null,
    busca: "",
  })

  const historico = [
    {
      data: new Date("2025-04-07T14:30:00"),
      tipo: "Login",
      descricao: "Login no Sistema",
    },
    {
      data: new Date("2025-04-01T15:30:00"),
      tipo: "Alteração",
      descricao: "Adição nova Gestão QA",
    },
  ]

  const usuarios = [
    {
      id: "001",
      nome: "Everton",
      grupo: "QA Processos",
      responsavel: "Tito Jorge",
      departamento: "TI",
      area: "Qualidade",
      ultimaAlteracao: "2025-04-04",
    },
    {
      id: "002",
      nome: "Mariana",
      grupo: "Desenvolvimento",
      responsavel: "Rafael Lima",
      departamento: "TI",
      area: "Desenvolvimento",
      ultimaAlteracao: "2025-04-03",
    },
    {
      id: "003",
      nome: "Carlos",
      grupo: "Infraestrutura",
      responsavel: "Marina Souza",
      departamento: "TI",
      area: "Infraestrutura",
      ultimaAlteracao: "2025-04-02",
    },
  ]

  const getTagSeverity = (tipo) =>
    tipo === "Login" ? "success" : tipo === "Alteração" ? "warning" : null

  const MenuItem = ({ icon: Icon, label, selected }) => (
    <div
      className={`p-2 rounded-md cursor-pointer flex items-center gap-2 ${
        selected
          ? "bg-blue-100 text-blue-600 font-semibold"
          : "text-gray-600 hover:bg-blue-100 hover:text-blue-600"
      }`}
    >
      <Icon size={18} />
      {label}
    </div>
  )

  const grupos = [
    { label: "Todos", value: null },
    ...new Set(usuarios.map((u) => u.grupo)),
  ].map((g) => ({
    label: g === null ? "Todos" : g,
    value: g === null ? "Todos" : g,
  }))

  const responsaveis = [
    { label: "Todos", value: null },
    ...new Set(usuarios.map((u) => u.responsavel)),
  ].map((r) => ({
    label: r === null ? "Todos" : r,
    value: r === null ? "Todos" : r,
  }))

  const departamentos = [
    { label: "Todos", value: null },
    ...new Set(usuarios.map((u) => u.departamento)),
  ].map((d) => ({
    label: d === null ? "Todos" : d,
    value: d === null ? "Todos" : d,
  }))

  const areas = [
    { label: "Todos", value: null },
    ...new Set(usuarios.map((u) => u.area)),
  ].map((a) => ({
    label: a === null ? "Todos" : a,
    value: a === null ? "Todos" : a,
  }))

  const usuariosFiltrados = usuarios.filter((user) => {
    const busca = filtros.busca.toLowerCase()
    const matchBusca =
      user.nome.toLowerCase().includes(busca) ||
      user.id.toLowerCase().includes(busca)

    const matchGrupo = filtros.grupo === null || user.grupo === filtros.grupo
    const matchResponsavel =
      filtros.responsavel === null || user.responsavel === filtros.responsavel
    const matchDepartamento =
      filtros.departamento === null ||
      user.departamento === filtros.departamento
    const matchArea = filtros.area === null || user.area === filtros.area

    return (
      matchBusca &&
      matchGrupo &&
      matchResponsavel &&
      matchDepartamento &&
      matchArea
    )
  })

  const limparFiltros = () => {
    setFiltros({
      grupo: null,
      responsavel: null,
      departamento: null,
      area: null,
      busca: "",
    })
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <Sidebar /> 

      {/* Conteúdo */}
      <div className="flex-1 p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold text-gray-800">
            Gerenciamento de Usuários
          </h2>
          <Button
            icon="pi pi-download"
            label="Download"
            className="p-button-outlined text-gray-600 hover:text-gray-800"
          />
        </div>

        {/* Filtros */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-5 mb-6">
          <Dropdown
            value={filtros.grupo}
            options={grupos}
            onChange={(e) => setFiltros({ ...filtros, grupo: e.value })}
            placeholder="Grupo"
            className="w-full p-3 border-gray-300 rounded-full shadow-sm"
          />
          <Dropdown
            value={filtros.responsavel}
            options={responsaveis}
            onChange={(e) => setFiltros({ ...filtros, responsavel: e.value })}
            placeholder="Responsável"
            className="w-full p-3 border-gray-300 rounded-full shadow-sm"
          />
          <Dropdown
            value={filtros.departamento}
            options={departamentos}
            onChange={(e) =>
              setFiltros({ ...filtros, departamento: e.value })
            }
            placeholder="Departamento"
            className="w-full p-3 border-gray-300 rounded-full shadow-sm"
          />
          <Dropdown
            value={filtros.area}
            options={areas}
            onChange={(e) => setFiltros({ ...filtros, area: e.value })}
            placeholder="Área"
            className="w-full p-3 border-gray-300 rounded-full shadow-sm"
          />
        </div>

        <div className="mb-6">
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            Buscar por Nome ou ID
          </label>
          <InputText
            value={filtros.busca}
            onChange={(e) => setFiltros({ ...filtros, busca: e.target.value })}
            className="w-full rounded-full bg-white mt-3 py-3 shadow-sm text-gray-700"
          />
        </div>

        <div className="mb-6 mt-10">
          <Button
            label="Limpar Filtros"
            icon="pi pi-filter-slash"
            onClick={limparFiltros}
            className="p-button p-button-danger text-gray-700 outline:none border:none"
          />
        </div>

        {/* Tabela de Usuários */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="grid grid-cols-6 gap-6 text-sm text-gray-600 font-semibold border-b pb-4 mb-4">
            <span>Nome</span>
            <span>Grupo</span>
            <span>Responsável</span>
            <span>Departamento</span>
            <span>Última Alteração</span>
            <span>Ações</span>
          </div>

          {usuariosFiltrados.length > 0 ? (
            usuariosFiltrados.map((user) => (
              <div
                key={user.id}
                className="grid grid-cols-6 gap-6 items-center text-sm py-4 border-b text-gray-700"
              >
                <span>{user.nome}</span>
                <span>{user.grupo}</span>
                <span>{user.responsavel}</span>
                <span>{user.departamento}</span>
                <span>
                  {new Date(user.ultimaAlteracao).toLocaleDateString("pt-BR")}
                </span>
                <Button
                  label="Histórico"
                  icon="pi pi-clock"
                  className="p-button-sm p-button-rounded p-button-info focus:outline-none"
                  onClick={() => setVisible(true)}
                />
              </div>
            ))
          ) : (
            <div className="text-center text-sm text-gray-600 py-6">
              Nenhum usuário encontrado.
            </div>
          )}
        </div>

        {/* Rodapé */}
        <Footer /> 
      </div>

      {/* Modal de Histórico */}
      <Dialog
        header="Histórico de Ações"
        visible={visible}
        style={{ width: "70rem" }}
        onHide={() => setVisible(false)}
        closable
        className="shadow-lg rounded-xl"
      >
        <div className="mb-4">
          <Calendar
            value={dataFiltroHistorico}
            onChange={(e) => setDataFiltroHistorico(e.value)}
            dateFormat="dd/mm/yy"
            placeholder="Filtrar por Data"
            showIcon
            className="w-full p-3 border-gray-300 rounded-xl shadow-sm"
          />
          <Button
            label="Limpar Filtro de Data"
            icon="pi pi-times"
            className="p-button-text mt-3 text-red-500"
            onClick={() => setDataFiltroHistorico(null)}
          />
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm text-left">
            <thead className="text-gray-500 font-medium border-b">
              <tr>
                <th className="py-2 px-4">Data e Hora</th>
                <th className="py-2 px-4">Tipo de Ação</th>
                <th className="py-2 px-4">Descrição</th>
              </tr>
            </thead>
            <tbody>
              {historico
                .filter((h) =>
                  dataFiltroHistorico
                    ? h.data.toDateString() ===
                      dataFiltroHistorico.toDateString()
                    : true
                )
                .map((h, i) => (
                  <tr key={i} className="border-b hover:bg-gray-50">
                    <td className="py-2 px-4 text-gray-800">
                      {h.data.toLocaleDateString("pt-BR")}{" "}
                      {h.data.toLocaleTimeString("pt-BR", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </td>
                    <td className="py-2 px-4">
                      <Tag value={h.tipo} severity={getTagSeverity(h.tipo)} />
                    </td>
                    <td className="py-2 px-4 text-gray-700">{h.descricao}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </Dialog>
    </div>
  )
}

export default GerenciamentoUsuarios
