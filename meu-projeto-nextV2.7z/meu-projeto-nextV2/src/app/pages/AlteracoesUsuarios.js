import React, { useState } from "react";
import { InputText } from "primereact/inputtext";
import { Dropdown } from "primereact/dropdown";
import { Button } from "primereact/button";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Divider } from "primereact/divider";
import { Image } from "primereact/image";
import { Link, useLocation } from "react-router-dom";
import { HomeIcon, BarChartIcon, UsersIcon, SettingsIcon, LogOutIcon, RefreshCwIcon } from "lucide-react";
import Footer from "components/Footer"
import Sidebar from "components/Sidebar";

export default function AlteracoesUsuarios() {
  const [filtros, setFiltros] = useState({
    dia: null,
    mes: null,
    ano: null,
    busca: "",
  });

  const [selectedResponsavel, setSelectedResponsavel] = useState(null);
  const [selectedArea, setSelectedArea] = useState(null);
  const [selectedSetor, setSelectedSetor] = useState(null);

  const location = useLocation();

  const dropdownValues = [
    { label: "01", value: "1" },
    { label: "02", value: "2" },
    // Adicionar mais valores conforme necessário
  ];

  const alteracoes = [
    {
      User_ID: "401869",
      Status: "Alterado",
      Diferencas:
        '[{"bd_db2": "INACTIVE", "coluna": "status", "bd_post": "ACTIVE"}]',
      User_Change: "409788",
      Data_Alteracao: "2025-04-01 15:00",
    },
  ];

  const gerarOpcoes = (campo) => {
    return dropdownValues; // Gerar opções baseadas nos valores do campo
  };

  const MenuItem = ({ icon: Icon, label, selected }) => (
    <div
      className={`p-2 rounded-md cursor-pointer flex items-center gap-2 ${selected
          ? "bg-blue-100 text-blue-600 font-semibold"
          : "text-gray-600 hover:bg-blue-100 hover:text-blue-600"
        }`}
    >
      <Icon size={20} />
      {label}
    </div>
  );

  return (
    <div className="flex min-h-screen bg-[#F9F9F9] text-[#1C1C1C]">
      {/* Sidebar */}
      <Sidebar /> 

      {/* Main content */}
      <div className="flex-1 p-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-semibold">Alterações dos Usuários</h1>
          <Button
            label="Download"
            icon="pi pi-download"
            className="p-button-text"
          />
        </div>

        {/* Filtros */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-5 mb-6">
          <Dropdown
            value={filtros.dia}
            options={gerarOpcoes("dia")}
            onChange={(e) => setFiltros({ ...filtros, dia: e.value })}
            placeholder="Dia"
            className="w-full p-3 border-gray-300 rounded-full shadow-sm"
          />
          <Dropdown
            value={filtros.mes}
            options={gerarOpcoes("mes")}
            onChange={(e) => setFiltros({ ...filtros, mes: e.value })}
            placeholder="Mês"
            className="w-full p-3 border-gray-300 rounded-full shadow-sm"
          />
          <Dropdown
            value={filtros.ano}
            options={gerarOpcoes("ano")}
            onChange={(e) => setFiltros({ ...filtros, ano: e.value })}
            placeholder="Ano"
            className="w-full p-3 border-gray-300 rounded-full shadow-sm"
          />
        </div>

        {/* Busca */}
        <div className="mb-6">
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            Busca por ID
          </label>
          <InputText
            value={filtros.busca}
            onChange={(e) => setFiltros({ ...filtros, busca: e.target.value })}
            className="w-full rounded-full bg-white mt-3 py-3 shadow-sm text-gray-700"
          />
        </div>

        {/* Título da Tabela */}
        <h2 className="text-xl font-semibold mb-2 py-4">Usuários</h2>

        {/* Tabela */}
        <div className="bg-white rounded-xl shadow p-4">
          <DataTable value={alteracoes} emptyMessage="Nenhuma alteração encontrada.">
            <Column field="User_ID" header="User_ID" />
            <Column field="Status" header="Status" />
            <Column field="Diferencas" header="Diferenças" />
            <Column field="User_Change" header="User_Change" />
            <Column field="Data_Alteracao" header="Data de Alteração" />
          </DataTable>
        </div>

        {/* Rodapé */}
        <Footer />
      </div>
    </div>
  );
}
