// src/App.js
"use client"
import { BrowserRouter as Router, Route, Routes } from "react-router-dom"
import Home from "./pages/Home"
import Estatisticas from "./pages/Estatisticas"
import GerenciamentoUsuarios from "./pages/GerenciamentoUsuarios"
import Estacoes from "./pages/Estacoes"
import AlteracoesUsuarios from "./pages/AlteracoesUsuarios"


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Estatisticas" element={<Estatisticas />} />
        <Route
          path="/GerenciamentoUsuarios"
          element={<GerenciamentoUsuarios />}
        />
        <Route
          path="/Estacoes"
          element={<Estacoes />}
        />
        <Route 
          path="/AlteracoesUsuarios"
          element={<AlteracoesUsuarios />} 
        />
      </Routes>
    </Router>
  )
}

export default App
